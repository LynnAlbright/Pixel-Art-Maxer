//Pixel Art maker elements which are assigned to variables
const tableGrid = document.getElementById("pixelCanvas");
const selectColor = document.getElementById("colorPicker");
const sizeChoice = document.getElementById("sizePicker");

const gridHeight = document.getElementById("inputHeight").value;
const gridWidth = document.getElementById("inputWidth").value;


//choose customizable grid size
sizeChoice.addEventListener('submit', function(e) => {
    submitevent.preventDefault(); // prevent refreshing the page

    const gridHeight = document.getElementById("inputHeight").value;
    const gridWidth = document.getElementById("inputWidth").value;

    makeGrid(gridHeight, gridWidth);
});

  //Grid creation
function makeGrid(gridHeight, gridWidth) {
  tableGrid.innerHTML="";
    //insert rows to tablegrid
  for (let y = 0; y <= gridHeight.value; y++) {
    let rowCreation = table.insertRow(y);
      for (let z = 0; z <= gridWidth.value; z++) {
        let cellCreation = rowCreation.insertCell(z);
        // change color of the cell
        cellCreation.addEventListener('click', function(e){
        const selctColor = document.getElementById('colorPicker');
        event.target.style.backgroundColor = selectColor.value;
        });
    }
  }
}
